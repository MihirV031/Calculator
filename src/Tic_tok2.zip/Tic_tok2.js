import React, { useState ,useEffect} from 'react';

const Tic_tok2 = () => {

    const [val, setVal] = useState(' ');
    const [val1, setVal1] = useState(' ');
    const [val2, setVal2] = useState(' ');
    const [val3, setVal3] = useState(' ');
    const [val4, setVal4] = useState(' ');
    const [val5, setVal5] = useState(' ');
    const [val6, setVal6] = useState(' ');
    const [val7, setVal7] = useState(' ');
    const [val8, setVal8] = useState(' ');
    const [temp, setTemp] = useState(1);
    const [ans, setAns] = useState('');
    const [disable, setDisable] = useState(false)
    const [disable1, setDisable1] = useState(false)
    const [disable2, setDisable2] = useState(false)
    const [disable3, setDisable3] = useState(false)
    const [disable4, setDisable4] = useState(false)
    const [disable5, setDisable5] = useState(false)
    const [disable6, setDisable6] = useState(false)
    const [disable7, setDisable7] = useState(false)
    const [disable8, setDisable8] = useState(false)
    const [disable9, setDisable9] = useState(false)



    const btn = () => {
        if (temp % 2 == 0) {
            setVal('o')
            // setDisable1(true);

        } else {
            setVal('x')
            // setDisable1(true);
        }
        win();
        setTemp(temp + 1);
        setDisable1(true);
    }


    const btn1 = () => {
        if (temp % 2 == 0) {
            setVal1('o')
            // setDisable2(true);
        } else {
            setVal1('x')
        }
        win();
        setTemp(temp + 1);
        setDisable2(true);
    }

    const btn2 = () => {
        if (temp % 2 == 0) {
            setVal2('o')
            // setDisable3(true);
        } else {
            setVal2('x')
        }
        win();
        setTemp(temp + 1);
        setDisable3(true);
    }

    const btn3 = () => {
        if (temp % 2 == 0) {
            setVal3('o')
            // setDisable4(true);
        } else {
            setVal3('x')
        }
        win();
        setTemp(temp + 1);
        setDisable4(true);
    }

    const btn4 = () => {
        if (temp % 2 == 0) {
            setVal4('o')
            // setDisable5(true);
        } else {
            setVal4('x')
        }
        win();
        setTemp(temp + 1);
        setDisable5(true);
    }

    const btn5 = () => {
        if (temp % 2 == 0) {
            setVal5('o')
            // setDisable6(true);
        } else {
            setVal5('x')
        }
        win();
        setTemp(temp + 1);
        setDisable6(true);
    }

    const btn6 = () => {
        if (temp % 2 == 0) {
            setVal6('o')
            // setDisable7(true);
        } else {
            setVal6('x')
        }
        win();
        setTemp(temp + 1);
        setDisable7(true);
    }

    const btn7 = () => {
        if (temp % 2 == 0) {
            setVal7('o')
            // setDisable8(true);
        } else {
            setVal7('x')
        }
        win();
        setTemp(temp + 1);
        setDisable8(true);
    }

    const btn8 = () => {
        if (temp % 2 == 0) {
            setVal8('o')
            // setDisable9(true);
        } else {
            setVal8('x')
        }
        win();
        setTemp(temp + 1);
        setDisable9(true);
    }

    useEffect(()=> {
        win();
      }, [val,val1,val2,val3,val4,val5,val6,val7,val8])

    const win = () => {
        if (
            (val === 'x' && val1 === 'x' && val2 === 'x') ||
            (val3 === 'x' && val4 === 'x' && val5 === 'x') ||
            (val6 === 'x' && val7 === 'x' && val8 === 'x') ||
            (val === 'x' && val3 === 'x' && val6 === 'x') ||
            (val1 === 'x' && val4 === 'x' && val7 === 'x') ||
            (val2 === 'x' && val5 === 'x' && val8 === 'x') ||
            (val === 'x' && val4 === 'x' && val8 === 'x') ||
            (val2 === 'x' && val4 === 'x' && val6 === 'x')
        ) {
            setAns('x player wins');
            setDisable1(true)
            setDisable2(true)
            setDisable3(true)
            setDisable4(true)
            setDisable5(true)
            setDisable6(true)
            setDisable7(true)
            setDisable8(true)
            setDisable9(true)
            setDisable(true);

        } else if (
            (val === 'o' && val1 === 'o' && val2 === 'o') ||
            (val3 === 'o' && val4 === 'o' && val5 === 'o') ||
            (val6 === 'o' && val7 === 'o' && val8 === 'o') ||
            (val === 'o' && val3 === 'o' && val6 === 'o') ||
            (val1 === 'o' && val4 === 'o' && val7 === 'o') ||
            (val2 === 'o' && val5 === 'o' && val8 === 'o') ||
            (val === 'o' && val4 === 'o' && val8 === 'o') ||
            (val2 === 'o' && val4 === 'o' && val6 === 'o')
        ) {
            setAns('o player wins');
            setDisable1(true)
            setDisable2(true)
            setDisable3(true)
            setDisable4(true)
            setDisable5(true)
            setDisable6(true)
            setDisable7(true)
            setDisable8(true)
            setDisable9(true)
            setDisable(true);

        }
        else if ((val == 'o' || val == 'x') &&
            (val1 == 'o' || val1 == 'x') &&
            (val2 == 'o' || val2 == 'x') &&
            (val3 == 'o' || val3 == 'x') &&
            (val4 == 'o' || val4 == 'x') &&
            (val5 == 'o' || val5 == 'x') &&
            (val6 == 'o' || val6 == 'x') &&
            (val7 == 'o' || val7 == 'x') &&
            (val8 == 'o' || val8 == 'x')) {
            setAns('drow games');

        }
    };

    const restart = () => {
        setVal(' ');
        setVal1(' ');
        setVal2(' ');
        setVal3(' ');
        setVal4(' ');
        setVal5(' ');
        setVal6(' ');
        setVal7(' ');
        setVal8(' ');
        setTemp(1);
        setAns('');
        setDisable1(false)
        setDisable2(false)
        setDisable3(false)
        setDisable4(false)
        setDisable5(false)
        setDisable6(false)
        setDisable7(false)
        setDisable8(false)
        setDisable9(false)
    };
    return (
        <div className='color1'>
            <div className="container1">
                <div className="btn">
                    <input type="button" value={val} onClick={() => btn()} disabled={disable1} />
                    <input type="button" value={val1} onClick={() => btn1()} disabled={disable2} />
                    <input type="button" value={val2} onClick={() => btn2()} disabled={disable3} />
                    <input type="button" value={val3} onClick={() => btn3()} disabled={disable4} />
                    <input type="button" value={val4} onClick={() => btn4()} disabled={disable5} />
                    <input type="button" value={val5} onClick={() => btn5()} disabled={disable6} />
                    <input type="button" value={val6} onClick={() => btn6()} disabled={disable7} />
                    <input type="button" value={val7} onClick={() => btn7()} disabled={disable8} />
                    <input type="button" value={val8} onClick={() => btn8()} disabled={disable9} />
                    <h6 className='i_win'> {ans} </h6>
                </div>
            </div>
            <button className='button' onClick={restart}>Restart</button>
        </div>
    )
}

export default Tic_tok2
